n = int(input("chọn 1 so từ 1 --->9 "))
if 1 <= n <= 9:
    print(f"Bang cửu chương số {n}:")
    for i in range(1, 10):
        print(f"{n} x {i} = {n * i}")
else:
    print("Số không hợp lệ.` Vui lòng nhập từ 1 đến 9.")